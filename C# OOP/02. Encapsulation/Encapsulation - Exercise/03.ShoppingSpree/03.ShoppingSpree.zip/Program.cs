﻿using ShoppingSpree.Models;
using System;

Product product = new(" ",  15);

Console.WriteLine();
