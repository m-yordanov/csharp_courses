﻿namespace RawData;

public class Engine
{
    public Engine(int speed, int power)
    {
        this.Speed = Speed;
        this.Power = Power;
    }
    public int Speed { get; set; }
    public int Power { get; set; }
}


